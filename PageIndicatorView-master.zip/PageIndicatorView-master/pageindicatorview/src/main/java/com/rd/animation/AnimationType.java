package com.rd.animation;

public enum AnimationType {NONE, COLOR, SCALE, WORM, SLIDE, FILL, THIN_WORM}
